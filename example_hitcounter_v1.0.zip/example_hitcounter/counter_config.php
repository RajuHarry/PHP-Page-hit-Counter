<?php
// change these values :
$localhost = 'localhost';
$dbuser =  '';
$dbpass = '';
$dbname = '';
$dbtablehits= 'hits';
$dbtableinfo= 'info';
$maxrows = 50; // Restrics how many entry´s are allowed in $dbtableinfo. if more then $maxrows , new entry´s will replace the oldest to keep your database small. 

?>
